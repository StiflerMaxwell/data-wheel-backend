// supabase/functions/_shared/database.types.ts
export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {
      raw_woocommerce_orders: {
        Row: {
          order_id: number;
          order_data: Json;
          created_at: string;
        };
        Insert: {
          order_id: number;
          order_data: Json;
          created_at?: string;
        };
        Update: {
          order_id?: number;
          order_data?: Json;
          created_at?: string;
        };
      };
      raw_gsc_data: {
        Row: {
          id: string;
          date: string;
          query: string | null;
          page: string | null;
          clicks: number | null;
          impressions: number | null;
          ctr: number | null;
          position: number | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          date: string;
          query?: string | null;
          page?: string | null;
          clicks?: number | null;
          impressions?: number | null;
          ctr?: number | null;
          position?: number | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          date?: string;
          query?: string | null;
          page?: string | null;
          clicks?: number | null;
          impressions?: number | null;
          ctr?: number | null;
          position?: number | null;
          created_at?: string;
        };
      };
      insights: {
        Row: {
          id: string;
          user_id: string | null;
          title: string;
          summary: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id?: string | null;
          title: string;
          summary: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string | null;
          title?: string;
          summary?: string;
          created_at?: string;
        };
      };
      recommendations: {
        Row: {
          id: string;
          insight_id: string;
          description: string;
          status: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          insight_id: string;
          description: string;
          status?: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          insight_id?: string;
          description?: string;
          status?: string;
          created_at?: string;
        };
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      [_ in never]: never;
    };
    Enums: {
      [_ in never]: never;
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
} 