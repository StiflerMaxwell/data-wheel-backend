/**
 * @file: sync-external-data/index.ts
 * @description: 
 * 
 * 这个 Edge Function 负责从外部数据源获取数据并存储到 Supabase 数据库中。
 * 支持以下数据源:
 * 1. WooCommerce (电子商务订单数据)
 * 2. Google Search Console (搜索性能数据)
 * 3. Google Analytics 4 (网站访问分析数据)
 * 
 * 使用方式: 
 * - 通过查询参数 type 指定要同步的数据源类型: 'status', 'woocommerce', 'gsc', 'ga4'
 * - 例如: ?type=woocommerce 将只同步 WooCommerce 数据
 */

// Import all dependencies from the centralized `deps.ts` file
import {
  serve,
  createClient,
  GoogleAuth,
  corsHeaders,
} from '../_shared/deps.ts';

// Main token acquisition function based on the user's best practice
async function getGoogleAccessToken(scopes: string[]) {
  // 1. Read the full JSON string from the Vault (set via Supabase Studio)
  const serviceAccountKeyJson = Deno.env.get("GA4_GSC_SERVICE_ACCOUNT_KEY");
  if (!serviceAccountKeyJson) {
      throw new Error("Secret GA4_GSC_SERVICE_ACCOUNT_KEY not found in Vault.");
  }
  
  // 2. Parse the JSON string into an object
  const credentials = JSON.parse(serviceAccountKeyJson);

  // --- 诊断日志 ---
  // 打印关键认证信息，用于排查权限问题
  // 我们只打印私钥的最后20个字符以确保安全
  console.log('Attempting to authenticate with:');
  console.log(`- Client Email: ${credentials.client_email}`);
  console.log(`- Private Key (last 20 chars): ...${credentials.private_key.slice(-20)}`);
  // --- 结束诊断日志 ---

  // 3. Use the parsed credentials for authentication
  const auth = new GoogleAuth({
      credentials: {
          client_email: credentials.client_email,
          private_key: credentials.private_key, // The private_key here is in the correct format
      },
      scopes,
  });

  const accessToken = await auth.getAccessToken();
  if (!accessToken) {
    throw new Error('Failed to get access token from GoogleAuth');
  }
  return accessToken;
}

/**
 * 从WooCommerce获取订单数据
 * @param supabaseClient Supabase客户端实例
 * @returns 处理结果
 */
async function syncWooCommerceData(supabaseClient: any) {
  try {
    // 从环境变量获取WooCommerce API配置
    const wooUrl = Deno.env.get('WOO_URL');
    const wooKey = Deno.env.get('WOO_KEY');
    const wooSecret = Deno.env.get('WOO_SECRET');
    
    if (!wooUrl || !wooKey || !wooSecret) {
      throw new Error('Missing WooCommerce API configuration');
    }

    // 获取最近30天的订单
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const dateAfter = thirtyDaysAgo.toISOString();
    
    // 构建API URL，包含身份验证和过滤参数
    const apiUrl = `${wooUrl}/wp-json/wc/v3/orders?consumer_key=${wooKey}&consumer_secret=${wooSecret}&after=${dateAfter}&per_page=100`;
    
    // 发送API请求获取订单数据
    const response = await fetch(apiUrl);
    if (!response.ok) {
      throw new Error(`WooCommerce API error: ${response.status} ${response.statusText}`);
    }
    
    const orders = await response.json();
    console.log(`Retrieved ${orders.length} orders from WooCommerce`);
    
    // 将订单数据写入数据库
    const results = [];
    for (const order of orders) {
      const { data, error } = await supabaseClient
        .from('raw_woocommerce_orders')
        .upsert({
          order_id: order.id.toString(),
          order_data: order,
          synced_at: new Date().toISOString(),
        }, {
          onConflict: 'order_id',
          returning: 'minimal'
        });
      
      if (error) {
        console.error(`Error storing order ${order.id}:`, error);
      } else {
        results.push(order.id);
      }
    }
    
    return {
      success: true,
      message: `Synced ${results.length} WooCommerce orders`,
      count: results.length,
    };
  } catch (error) {
    console.error('Error in syncWooCommerceData:', error);
    return {
      success: false,
      message: `Error syncing WooCommerce data: ${error.message}`,
      error: error.message,
    };
  }
}

/**
 * 从Google Analytics 4获取分析数据
 * @param supabaseClient Supabase客户端实例
 * @returns 处理结果
 */
async function syncGA4Data(supabaseClient: any, startDate: string, endDate: string) {
  try {
    // 获取Google OAuth访问令牌
    const accessToken = await getGoogleAccessToken([
      'https://www.googleapis.com/auth/analytics.readonly',
    ]);
    
    // 从环境变量获取GA4属性ID
    const propertyId = Deno.env.get('GA4_PROPERTY_ID');
    if (!propertyId) {
      throw new Error('Missing GA4_PROPERTY_ID in environment variables');
    }
    
    // 构建GA4 API请求体
    const requestBody = {
      dateRanges: [
        {
          startDate,
          endDate
        }
      ],
      dimensions: [
        { name: 'date' },
        { name: 'sessionSource' },
        { name: 'sessionMedium' }
      ],
      metrics: [
        { name: 'sessions' },
        { name: 'totalUsers' },
        { name: 'newUsers' },
        { name: 'conversions' }
      ]
    };
    
    // 发送GA4 Data API请求
    const response = await fetch(
      `https://analyticsdata.googleapis.com/v1beta/properties/${propertyId}:runReport`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestBody)
      }
    );
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`GA4 API error (${response.status}): ${errorText}`);
    }
    
    const reportData = await response.json();
    
    // 处理并保存GA4数据
    const rows = reportData.rows || [];
    console.log(`Retrieved ${rows.length} rows from GA4`);
    
    if (rows.length === 0) {
      return {
        success: true,
        message: 'No new GA4 data to sync.',
        count: 0,
      };
    }

    // 1. 准备批量写入的数据
    const recordsToUpsert = rows.map(row => {
      // 提取维度和指标值
      const [dateStr, source, medium] = row.dimensionValues.map(dim => dim.value);
      const [sessions, totalUsers, newUsers, conversions] = row.metricValues.map(metric => parseInt(metric.value, 10));
      
      // 格式化日期 (YYYYMMDD to YYYY-MM-DD)
      const date = `${dateStr.substr(0,4)}-${dateStr.substr(4,2)}-${dateStr.substr(6,2)}`;
      
      return {
        date,
        source,
        medium,
        sessions,
        total_users: totalUsers,
        new_users: newUsers,
        conversions,
        synced_at: new Date().toISOString()
      };
    });
    
    // 2. 执行一次性的批量写入操作
    const { error } = await supabaseClient
      .from('raw_ga4_data')
      .upsert(recordsToUpsert, {
        onConflict: 'date, source, medium',
        returning: 'minimal'
      });
      
    if (error) {
      console.error(`Error during bulk upsert for GA4 data:`, error);
      throw error; // 抛出错误以便上层捕获
    }
    
    return {
      success: true,
      message: `Successfully synced ${recordsToUpsert.length} GA4 data entries.`,
      count: recordsToUpsert.length,
    };
  } catch (error) {
    console.error('Error in syncGA4Data:', error);
    return {
      success: false,
      message: `Error syncing GA4 data: ${error.message}`,
      error: error.message,
    };
  }
}

/**
 * 从Google Search Console获取搜索分析数据
 * @param supabaseClient Supabase客户端实例
 * @returns 处理结果
 */
async function syncGSCData(supabaseClient: any, startDate: string, endDate: string) {
  try {
    const accessToken = await getGoogleAccessToken([
      'https://www.googleapis.com/auth/webmasters.readonly',
    ]);
    
    const siteUrl = Deno.env.get('GSC_SITE_URL');
    if (!siteUrl) {
      throw new Error('Missing GSC_SITE_URL in environment variables');
    }
    
    let allRows = [];
    let startRow = 0;
    const rowLimit = 25000; // 使用API允许的最大值
    let hasMoreData = true;

    // 循环获取所有分页数据
    while (hasMoreData) {
      const requestBody = {
        startDate,
        endDate,
        dimensions: ['date', 'page', 'query'],
        rowLimit,
        startRow,
      };
      
      console.log(`Fetching GSC data... Start Row: ${startRow}`);

      const response = await fetch(
        `https://www.googleapis.com/webmasters/v3/sites/${encodeURIComponent(siteUrl)}/searchAnalytics/query`,
        {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
          body: JSON.stringify(requestBody)
        }
      );
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`GSC API error (${response.status}): ${errorText}`);
      }
      
      const reportData = await response.json();
      const rows = reportData.rows || [];
      
      if (rows.length > 0) {
        allRows = allRows.concat(rows);
      }

      // 如果返回的行数小于请求的限制，说明是最后一页
      if (rows.length < rowLimit) {
        hasMoreData = false;
      } else {
        // 否则，准备获取下一页
        startRow += rowLimit;
      }
    }
    
    console.log(`Retrieved a total of ${allRows.length} rows from GSC.`);

    if (allRows.length === 0) {
      return { success: true, message: 'No new GSC data to sync.', count: 0 };
    }

    const recordsToUpsert = allRows.map(row => {
      const [date, page, query] = row.keys;
      return {
        date, page, query,
        clicks: row.clicks,
        impressions: row.impressions,
        ctr: row.ctr,
        position: row.position,
        synced_at: new Date().toISOString()
      };
    });

    const { error } = await supabaseClient
      .from('raw_gsc_data')
      .upsert(recordsToUpsert, { onConflict: 'date, page, query', returning: 'minimal' });
      
    if (error) {
      console.error(`Error during bulk upsert for GSC data:`, error);
      throw error;
    }

    return {
      success: true,
      message: `Successfully synced ${recordsToUpsert.length} GSC data entries.`,
      count: recordsToUpsert.length,
    };
  } catch (error) {
    console.error('Error in syncGSCData:', error);
    return {
      success: false,
      message: `Error syncing GSC data: ${error.message}`,
      error: error.message,
    };
  }
}

/**
 * 获取同步状态
 * @returns 同步状态信息
 */
async function getStatus() {
  return {
    status: 'online',
    version: '1.0.0',
    availableSyncTypes: ['status', 'woocommerce', 'ga4', 'gsc'],
    timestamp: new Date().toISOString(),
  };
}

serve(async (req) => {
  // 处理CORS预检请求
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      headers: corsHeaders,
      status: 204,
    });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('Unauthorized: Missing Authorization header.');
    }
    
    // 创建Supabase客户端，并将请求中的Authorization头透传过去
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '', // 使用 Service Role Key 以拥有更高权限
      { global: { headers: { Authorization: authHeader } } }
    );
    
    // 解析请求参数
    const url = new URL(req.url);
    const syncType = url.searchParams.get('type');
    
    // 获取日期参数，如果未提供则默认为昨天
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const defaultDate = yesterday.toISOString().split('T')[0];
    
    const startDate = url.searchParams.get('startDate') || defaultDate;
    const endDate = url.searchParams.get('endDate') || startDate; // 如果没有endDate，就默认为startDate

    let result;
    
    // 根据同步类型执行相应的操作
    switch (syncType) {
      case 'woocommerce':
        result = await syncWooCommerceData(supabaseClient);
        break;
        
      case 'ga4':
        result = await syncGA4Data(supabaseClient, startDate, endDate);
        break;
        
      case 'gsc':
        result = await syncGSCData(supabaseClient, startDate, endDate);
        break;
        
      case 'status':
      default:
        result = await getStatus();
        break;
    }
    
    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    });
  } catch (error) {
    console.error('Error processing request:', error);
    
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: error.message.includes('Unauthorized') ? 401 : 500,
    });
  }
}) 