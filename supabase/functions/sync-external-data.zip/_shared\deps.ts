// _shared/deps.ts
export { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
export { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
// Import from the local vendored file for maximum reliability
export { GoogleAuth } from './vendor/google_auth.ts';
export { corsHeaders } from './cors.ts'; 